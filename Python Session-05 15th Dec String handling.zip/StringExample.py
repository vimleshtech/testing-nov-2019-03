s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(len(s))
print(s.strip())
s = s.strip()
print(len(s))

print(s.count('a'))

s =s.replace('i','xy')
print(s)


l = list(s)
print(l)


o = s.split(' ')
print(o)


print(s[2:5]) #substring 

#condition
if s.isupper():
    print('in upper case  ')
else:
    print("in lower case ")


if s.islower():
    print('in lower case  ')
else:
    print("in upper case ")





if s.istitle():
    print('in title case  ')
else:
    print("not in title case ")





if s.isdigit():
    print('numeric ')
else:
    print("not numeric ")


