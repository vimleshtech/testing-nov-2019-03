#-----Class 5_StringHandling_Practice--------
'''
#C1:  WAP to count the number of spaces, tabs and new line characters in
#a given string.

s = input('Enter the string :')

print(s.strip())
print(len(s))

print(s.capitalize())

print(s.title())

l=list(s)
print(l)

o = s.split()
print(o)

if(s.isupper()):
    print('True')
else:
    print('False')

'''


#C2: WAP to input a character and a string. Each occurrence of a character in the
#string should be converted to opposite case i.e. upper to lower case or vice versa.

s = input('Enter the string')
l = list(s)
for c in l:
    

    if c.isupper():
        print(c.lower(),)
    else:
        print(c.upper(),)







#C3: WAP to count the number of words and number of characters in a given line
#of text except the spaces.

s = input('Enter the string :')
w = s.split(' ')
print(len(w))

      



#C4: WAP to input a multi word string and produce a string in which first
#letter of each word is capitalized.

c = s.capitalize()
print(c)



#C5: WAP to count the numbers of vowels, consonants, digits and special
#symbols in a given string.

s = input('enter the string')
a = ['a','e','i','o','u']

l = list(s)
vc = 0
dc =0
oc =0
for c in l:
    if c in a:
        vc=vc+1
    elif c.isdigit():
        dc=dc+1
    else:
        oc=oc+1
        
        
print(vc)
print(dc)
print(oc)




        





































