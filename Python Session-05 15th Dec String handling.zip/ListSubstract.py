#d 3
a = []
b = []

for i in range(5):
    d = int(input('enter data for a :'))
    a.append(d)


for i in range(5):
    d = int(input('enter data for b :'))
    b.append(d)


#substract
for i in range(len(a)):
    print(a[i] - b[i])

#d8
a = []

for i in range(5):
    d = int(input('enter data for a :'))
    a.append(d)
    a.sort()
    print(a)


    


    


    
