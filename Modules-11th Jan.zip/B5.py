x = int(input('enter num :'))

if x%7 ==0:
    print('divisiable')
else:
    print('not -divisiable')


