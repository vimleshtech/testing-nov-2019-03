
st = input('enter string  :')
ch = input('enter char :')

#print(st)
l = list(st)
#print(l)

for c in l:
    #if ch.lower() ==c.lower():
    print(c.swapcase(),end='')
    
