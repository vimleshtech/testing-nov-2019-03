import time
t = time.localtime()
#print(t)
print(t.tm_year,'-',t.tm_mon,'-',t.tm_mday)



ticks = time.time()
print(ticks)

localtime = time.asctime( time.localtime(time.time()) )
print(localtime)


import calendar
cal = calendar.month(2008, 1)
print(cal)

import datetime

print ("Current date and time: " , datetime.datetime.now())
print ("Or like this: " ,datetime.datetime.now().strftime("%y-%m-%d-%H-%M"))








