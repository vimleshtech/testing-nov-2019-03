salary = int(input('enter salary '))

if salary>=5000 and salary<=10000:
    hra =salary*.10
    da =salary*.05
elif salary>=10001 and salary<=15000:
    hra =salary*.15
    da =salary*.08
else:
    hra =0
    da =0

print(hra)
print(da)


    
    
