
import os

#change directory
os.chdir(r'C:\Users\vkumar15\Desktop\Learning & Training')


#get current directory
p  = os.getcwd()
print(p)

#get list of files and folder
f = os.listdir()
print(f)


print(len(f))
#get .txt file count
tc = 0

#read content from all .txt files
for file in f:
    if file.endswith('.txt'):
        print(file)
        data = open(file)
        print(data.read())
        tc =tc+1

print(tc)




        
    

