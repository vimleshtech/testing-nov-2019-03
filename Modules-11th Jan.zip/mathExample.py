#import math
#x= math.factorial(5)
#print(x)

#import math as m
#x= m.factorial(5)
#print(x)

#from math import * #* all functions
#x= factorial(5)
#print(x)


from math import factorial,sqrt,pow
x =sqrt(4)
print(x)

x =factorial(4)
print(x)

print(pow(44,5))


import random
print(chr(random.randint(1,100))+str(random.randint(1000,9999)))










