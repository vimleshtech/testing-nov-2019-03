a =44
b =5555
c = a+b

print(c)
