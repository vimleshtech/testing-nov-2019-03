amt = int(input('enter sale amt : '))

t = 0

if amt>1000:
    t = amt*.18 #amt*18/100

total = amt+t

print('total amt is :',total)
