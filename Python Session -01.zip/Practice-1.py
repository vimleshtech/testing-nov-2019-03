#Square of a given number:

a = int(input("Enter the number: "))
c = a**2


print(c)
