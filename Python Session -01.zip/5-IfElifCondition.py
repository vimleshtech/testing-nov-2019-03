amt = int(input('enter sale amt : '))

t = 0

if amt>1000:
    t = amt*.18 #amt*18/100
elif amt>500:
    t = amt*.12
elif amt>100:
    t = amt*.10
else:
    t = amt*.05

    
total = amt+t
print('total amt is :',total)
