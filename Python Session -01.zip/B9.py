hs = int(input('enter num : '))
es = int(input('enter num : '))
cs = int(input('enter num : '))
ms = int(input('enter num : '))
ss= int(input('enter num : '))

total = hs+es+cs+ms+ss
avg = total /5

if avg>=60:
    print("First Division")
elif avg>=50:
    print("Second")
elif avg>=40:
    print("Third")
else:
    print("Fail")


    
