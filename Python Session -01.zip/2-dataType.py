a = input('enter data :' )
b = input('enter data :' )

print(type(a))
print(type(b))


#type conversion
a = int(a)
b = int(b)


print(type(a))
print(type(b))


#add
c =a+b
print('sum of two numbers ',end='\t')  #print and don't changle line 
print(c)

#format
print('sum of {} and {} is {} '.format(a,b,c))
print('sum of {1} and {0} is {2} '.format(a,b,c))







