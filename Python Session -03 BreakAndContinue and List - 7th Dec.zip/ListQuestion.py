'''
a =[] #declare empty list


#fill / add data in list
for x in range(10):
    d = int(input('enter data :'))
    a.append(d)

##find given value
y = int(input('enter data to search :'))



counter = 0
for data in a:
    if data==y:
        counter = counter +1

print(y,' found ',counter,' times')
'''

'''

#wap to subtract 2 arrays of same size

a=[]
b = []
for x in range (5):
    i=int(input('the first list is :'))
    a.append(i)
for m in range (5):
    y=int(input('the second list is :'))
    b.append(y)

print(a)
print(b)

for i in range(0,len(a)):
    
    print('the value is',a[i]-b[i])
    
'''

'''
#wap to input the sales made by salesman in every month of a given year and find total,average,maximum,minimum

a=[]
for x in range (12):
    i=int(input('the sale is:'))
    a.append(i)
    


print(sum(a))
avg= sum(a)/len(a)
print('average is ',avg)
print(max(a))
print(min(a))
'''
#wap to input the marks of 10 students in an array and display the marks

marks=[]
for x in range (1,11):
    m=int(input('the marks of student '))
    marks.append(m)
    
    
    
print(marks)
          
    








