for r in range(1,4): #1 to 3 
    for c in range(1,5): # 1 to 2
        print(c,end='\t')
    print()
