d = open(r'C:\Users\vkumar15\Desktop\out.txt','w') #new file the write content
d.write('hi, this is test content')
d.close()


d = open(r'C:\Users\vkumar15\Desktop\out.txt','a') #append data in existing file
d.write('hi, this is test content')
d.close()


