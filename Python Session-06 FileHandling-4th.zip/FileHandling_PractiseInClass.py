#wap to get word count from file.

d = open(r'C:\Users\vkumar15\Desktop\out.txt','r')
data = d.readlines()
wc = 0
for r in data:
    c = r.split(' ')
    wc =wc+len(c)

print('word count ',wc)


#wap to get row count from file
#Logic-1
d = open(r'C:\Users\vkumar15\Desktop\out.txt','r')
data = d.readlines()
print('row count ',len(data))

#Logic-2
d = open(r'C:\Users\vkumar15\Desktop\out.txt','r')
data = d.readlines()
rc = 0
for r in data:
    rc = rc+1
    
print('row count ',rc)


#wap to get data from user(console) and write to file
data = input('enter data :')
d= open(r'C:\Users\vkumar15\Desktop\out.txt','a')

d.write(data)

d.close()









