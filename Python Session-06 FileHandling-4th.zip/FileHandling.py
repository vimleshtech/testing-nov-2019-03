f = open(r'C:\Users\vkumar15\Desktop\out.txt','r')

#read all content from file
#print(f.read())

#read first line from file
#print(f.readline())

#read all data and convert to list
data = f.readlines()
print(data)

for r in data:
    print(r)

f.close() #save the data in file




