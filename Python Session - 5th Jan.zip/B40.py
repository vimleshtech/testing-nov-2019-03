a =  int(input('enter first number :')) #default input type is str , so we have to type cast
b = int(input('enter second number :'))

s = 0
while a<=b:
    if a%2 ==0 and a%5 != 0 and a%3 ==0:
        s =s+a

    a =a+1

print('sum of all numbers based on given conditon ',s)

    
        
        
