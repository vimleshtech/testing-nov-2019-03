
sales = [111,33,4556,54,32,3,556,777,44]

print('count ',len(sales))
print('min ',min(sales))
print('max ',max(sales))
print('total ',sum(sales))

sales.sort()
print(sales) #print in asc

print(sales[::-1]) #in desc


#add new value
sales.append(100)
sales.append(101)
print(sales)

sales.pop()
sales.pop()
sales.pop()
print(sales)

sales.insert(2,567)
print(sales)

if 33 in sales:
    sales.remove(33)
    
print(sales)


sales.remove(sales[2])






















