#b32
a =  int(input('enter first number :')) #default input type is str , so we have to type cast
b = int(input('enter second number :'))
c =(b-a+1)


s = 0
while a<=b:
    s =s+a
    a =a+1


print('sum of given range ',s)
print('avg of given range ', (s/c) )


    
