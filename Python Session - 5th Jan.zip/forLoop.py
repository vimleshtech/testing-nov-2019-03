#for loop

for x in range(5):
    print(x)
    

#print odd number series

for x in range(1,100,2):  #start from 1, conditon till 9, and increment  by 2
    print(x)
    
#print in reverse
for x in range(100,1,-1): #from 100 to 2, decrement by -1
    print(x)
    
    
    
