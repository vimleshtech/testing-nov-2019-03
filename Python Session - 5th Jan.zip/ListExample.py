
#declare list
a = [11,33,44,566,77,55,True]

#print all
print(a)

print(a[0]) #print first value

#print count
print(len(a))

#print last element
print(a[-1])

#print 2nd last element
print(a[-2])


#slicer : print value from given index range
print(a[0:3]) #from 0 to <3
print(a[:3])  #from 0 to <3

print(a[2:4])

##
print(a[::])
print(a[::-1]) #print in reverse
print(a[::-2])

a.pop()
print(a[::-1])



###iterate every element one by one
for i in a: #[11,33,555]
    print(i)

#or
for i in range(0,len(a)):
    print(a[i])
    
    






