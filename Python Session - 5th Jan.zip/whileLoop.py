#WAP to print series from 1 to 10 using while loop

i = 1 #auto memory allocaton  #init 
while i<10: #condition 
    print(i)
    i=i+1  #step / increment


print('------------------')
#print seriese in reverse
x = 10
while x>0:
    print(x)
    x =x-1

print('------------------')
#print in same line(row)
x = 10
while x>0:
    #print(x)  #print and new line
    print(x,end=',') #print and don't change line
    
    x =x-1

#wap to print table of given number
n = int(input('enter numebr to print table :'))
i =1
while i<=10:
    #print(i*n)
    print('{} * {} = {}'.format(n,i,n*i))
    
    i = i+1


#wap to print sum of all even and odd numbers between two given numbers
a =12
se = 0
so = 0
while a<=120:
    if a%2 ==0:
        se=se+a

    else:
        so=so+a

    a=a+1

print('sum of all even no ',se)
print('sum of all odd no ',so)

    
        

    


    

    



