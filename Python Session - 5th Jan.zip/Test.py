a= [11,33,44,566,7677]
#    0  1   2  3   4

for x in range(0,len(a)):
    print(a[x])
    
    

#add data in list dynamically
sales = [] #declare empty list
for i in range(10):
    d = int(input('enter data :'))
    sales.append(d)



print(sales)

