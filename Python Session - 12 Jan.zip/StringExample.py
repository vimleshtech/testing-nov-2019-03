s = input('enter string :')

print(s.upper())
print(s.lower())
print(s.title())
print(s.capitalize())
print(s.swapcase())


l = list(s)
print(l)

word = s.split()
print(word)



print(s.replace('a','xy'))

print(len(s))

print(s.count('a'))


print(ord(s[0]))
print(chr(65))


print(s.strip()) #trim 
print(s.lstrip())
print(s.rstrip())


##
if s.endswith('a'):
    print('ending with a')
else:
    print('not ending with a')
    








print(s.strip())
