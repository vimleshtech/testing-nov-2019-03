import mysql.connector as con


dbcon = con.connect(host='localhost',user='root',password='root',database='hrms')
cmd = dbcon.cursor()


#read data 

cmd.execute('select * from emp_2017')

data = cmd.fetchall()

#print(data)
for row in data:
    #print(row)
    print(row[0],row[1])
    
#save data
cmd.execute("insert into emp_2017(eid,name,gender) values(11,'kshitiz','male')")
dbcon.commit()
print('data is saved')

  
