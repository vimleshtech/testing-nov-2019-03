n = int(input('enter data :'))
d = int(input('enter data :'))

#div
try:
    if d<0:
       ex = ZeroDivisionError('divisor cannot be less than 0')
       raise ex #go to except block (matching except block)
    
    o =n/d
    print('div  =',o)

except ZeroDivisionError as e:
    print(e)
    
except NameError as er:
    print(er)
except IndexError as er:
    print(er)    
except:
    #pass
    print('there is some error, plz reenter data !!')
    

finally:
    print('end of div block ')
    #close 
    

#add
o =n+d
print("addition of two numebrs =",o)


