#declare list
a = [111,333,5,56322,4,5]
print(a)
print(type(a))

print(len(a))
print(max(a))
print(min(a))
print(sum(a))

a.sort()
print(a)

#slicer
print(a[0])
print(a[0:4]) #from 0 to 3
print(a[-1]) #last value
print(a[::-1]) #in reverse


#append
a.append(14)
a.append(104)
print(a)


a.pop()
print(a)


#insert
a.insert(3,400)
print(a)

a.remove(5)
print(a)

#iterate the list using loop
i =0
while i<len(a):
    print(a[i])
    i=i+1


#for
for x in a:
    print(x)
    



    















