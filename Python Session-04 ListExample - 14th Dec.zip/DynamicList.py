d =[55,666,'fff'] #empty list

for i in range(5):
    a = int(input('enter data :'))
    d.append(a)

print(d)

            
