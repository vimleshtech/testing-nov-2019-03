rn = int(input('enter rno :'))
name =input('enter name :')

ms = int(input('enter ms :'))
es = int(input('enter es :'))
cs = int(input('enter cs :'))
hs = int(input('enter hs:'))
ss = int(input('enter ss :'))

total = hs+es+cs+ms+ss
avg = total/5

print('name is :',name)
print('rno is :',rn)
print('total score is :',total)
print('average score is :',avg)

