#D1: WAP to input the marks of 10 students in an array of integers and display
#the marks.

List1 = [50,40,90,45,66,78,88,98,100,39]
print(List1)
print(len(List1))
print(max(List1))
print(min(List1))



#D2: WAP to search how many times a number is present in an array.
List2 = [55,66,77,77,88,87,99,99,33,99]
List2.d
