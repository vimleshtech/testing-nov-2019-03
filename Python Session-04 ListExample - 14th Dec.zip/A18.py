import time

print(time.localtime())

l = int(input('enter data :'))
w = int(input('enter data :'))

area = l*d
print(area)

 
