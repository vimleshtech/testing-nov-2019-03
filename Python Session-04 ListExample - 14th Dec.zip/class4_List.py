#D1: WAP to input the marks of 10 students in an array of integers and display
#the marks.

List1 = [50,40,90,45,66,78,88,98,100,39]
print(List1)
print(len(List1))
print(max(List1))
print(min(List1))


'''
#D2: WAP to search how many times a number is present in an array.
List2 = [55,66,77,77,88,87,99,99,33,99]
List2.duplicate()



#D3: WAP to subtract two arrays of the same size.
List2.remove(99)
print(List1)


#D4: WAP to input the sales made by a salesman in every month of a given year
#and find out the total,average, maximum and minimum sales.

sales = int(input('Enter sales in a month'))



#D5: WAP to calculate the average of 10 values stored in an array and display
#all those values which are more than the calculated average.

array = [1,2,3,4,5,6,7,8,9,10]

total = sum(array)
avg = total/len(array)

print(array)
print('total array is: ' ,total)
print('total avg is:',avg)




#D7: WAP to reverse an array of floats.
List1 = [1.00,3.33,4.43,5.54,6,45,10.03,9.45,3.56]
print(List1)
print(type(List1))
print(List1[::-1])

'''

#D6: WAP which finds the locations and values of largest and second largest
#element in a one dimensional array.
a = [100,23,45,55,66,77]
print(a)
m = max(a)
print(m)


for i in range(len(a)):
    if m == a[i]:
        print(m,' at location is ',i)




        


























