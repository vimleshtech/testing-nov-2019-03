#WAP to get table of given number
n = int(input('enter num :'))

i =1
while i<=10:
    #print(n*i)
    #print(n,'*',i,'=',n*i)
    print('{}*{}={}'.format(n,i,n*i))
    i=i+1
    

#WAP to get print of all even number between two given range
sn = int(input('enter data '))
en = int(input('enter data '))

while sn<=en:
    if sn%2 ==0: #is even
        print(sn)
    sn+=1
    

    
