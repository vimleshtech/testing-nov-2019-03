#while example
#WAP to print series from 1 to 10
i =1
while i<=10:
    print(i)
    i =i+1


#WAP to print series from 1 to 10 in single line
i =1
while i<=10:
    print(i,end='')
    i =i+1

#WAP to priint series from 10 to 1
i =10
while i>0:
    print(i)
    i-=1 #i=i-1

#WAP to get sum of all even and number number between 1 to 100
se=0
so=0
i =1
while i<=100:
    if i%2 ==0: #is even no
        se+=i
    else:
        so+=i
    i+=1

print('sum of all even number ',se)
print('sum of all odd number ',so)

      



    
    



        




    
    

