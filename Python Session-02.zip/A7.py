
a =int( input('enter data :'))
b =int( input('enter data :'))
c = int( input('enter data :'))
d = int( input('enter data :'))


a = a**3 #a pow 3
b = b**3 
c = c**3 
d = d**3 


if a+b+c == d:
    print('condition is match',end='')
    print(a,b,c,d)
    print(a+b+c,d)
else:
    print('condition is not match')
    print(a,b,c,d)
    print(a+b+c,d)
    





