#WAP to print a series from 0 to 9
for x in range(10):
    print(x)

#WAP to print a series from 1 to 9
for x in range(1,10):
    print(x)

    
#WAP to print a series from 9 to 1
for x in range(9,0,-1):
    print(x)



    
#WAP to print a series 1 3 5 
for x in range(1,10,2):
    print(x)



    
